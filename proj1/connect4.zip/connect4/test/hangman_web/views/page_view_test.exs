defmodule HangmanWeb.PageViewTest do
  use HangmanWeb.ConnCase, async: true
end
