defmodule HangmanWeb.LayoutViewTest do
  use HangmanWeb.ConnCase, async: true
end
