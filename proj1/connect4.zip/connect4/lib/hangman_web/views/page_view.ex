defmodule HangmanWeb.PageView do
  use HangmanWeb, :view
end
