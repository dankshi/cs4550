defmodule HangmanWeb.LayoutView do
  use HangmanWeb, :view
end
